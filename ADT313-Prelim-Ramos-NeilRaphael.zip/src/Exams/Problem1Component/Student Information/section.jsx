import React from 'react'
import './CSS/section.css'

function StudentSection({ section }) {
  return (
    <h2 className='text-h2'>Section: {section}</h2>
  )
}

export default StudentSection