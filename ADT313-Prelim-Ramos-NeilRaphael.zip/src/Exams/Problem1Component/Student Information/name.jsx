import React from 'react'
import './CSS/name.css'

function StudentName({ firstname, lastname }) {
    return (
        <div>
            <p className='text-gray'>Name: <span className='firstname-color'>{firstname}</span> <span className='lastname-color'>{lastname}</span> </p>
        </div>
    );
}

export default StudentName