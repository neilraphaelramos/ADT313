import React from 'react'
import './CSS/course.css'

function StudentCourse({ course }) {
  return (
    <h2 className='text-h2'>Course: {course}</h2>
  )
}

export default StudentCourse