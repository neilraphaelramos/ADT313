import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true); 
  const [inputValue, setInputValue] = useState(''); 
  const [typing, setTyping] = useState(false);

  const useDebounce = (value, delay = 500) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    const timerRef = useRef();

    useEffect(() => {
      timerRef.current = setTimeout(() => setDebouncedValue(value), delay);

      return () => {
        clearTimeout(timerRef.current);
      };
    }, [value, delay]);

    return debouncedValue;
  };

  const debouncedInputValue = useDebounce(inputValue, 500);

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
    setTyping(true);    
  };

  useEffect(() => {
    if (debouncedInputValue === inputValue) {
      setIsLoading(false); 
      setTyping(false);    
    }
  }, [debouncedInputValue, inputValue]);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type='text' value={inputValue} onChange={handleInputChange} />
          <p>{typing ? "User is typing..." : "User is idle..."}</p>
        </div>
      )}
    </>
  );
}
