import { useState } from "react";

export default function Problem4() {
  const [name, setName] = useState('')
  const [yearlevel, setYearLevel] = useState('')
  const [course, setCourse] = useState('BSCS')

  const handleChange = (event) => {
    setName(event.target.value);
  };

  const handleRadioChange = (event) => {
    setYearLevel(event.target.value);
  };

  function handleSelectionChange (e) {
    setCourse(e.target.value)
  }


  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input value={name} type='text' onChange={handleChange} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input
          type='radio'
          id='firstYear'
          name='yearlevel'
          value='First Year'
          checked={
            yearlevel === "First Year"
          }
          onChange={handleRadioChange}
        />
        <label for='firstYear'>Fist Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          checked={
            yearlevel === "Second Year"
          }
          onChange={handleRadioChange}
        />
        <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          checked={
            yearlevel === "Third Year"
          }
          onChange={handleRadioChange}
        />
        <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
          checked={
            yearlevel === "Fourth Year"
          }
          onChange={handleRadioChange}
        />
        <label for='fourthYear'>Fourth Year</label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fifth Year'
          checked={
            yearlevel === "Fifth Year"
          }
          onChange={handleRadioChange}
        />
        <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input
          type='radio'
          id='irregular'
          name='yearlevel'
          value='Irregular'
          checked={
            yearlevel === "Irregular"
          }
          onChange={handleRadioChange}
        />
        <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select 
          value={course}
          onChange={handleSelectionChange}
        >
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>
      <div>
        <p>Name: {name}</p>
        <p>Year Level: {yearlevel}</p>
        <p>Course: {course}</p>
      </div>
    </>
  );
}
