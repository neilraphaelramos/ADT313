import React from 'react';
import './../design-UI/style.css';
import { useTheme } from './../themecomponent/ThemeContext';

const Datastudentinfo = () => {
    const { theme } = useTheme();

    return (
        <div className={`container ${theme}`}>
            <div className={`box ${theme}`}>
                <h1 className={`colorfont ${theme}`}>Neil Raphael Ramos</h1>
                <h2 className={`colorfont ${theme}`}>BSIT-3A</h2>
            </div>
        </div>
    );
};

export default Datastudentinfo;