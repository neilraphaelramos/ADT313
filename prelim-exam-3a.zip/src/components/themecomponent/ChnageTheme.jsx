import React from 'react';
import { useTheme } from './ThemeContext'; // Adjust the path as necessary

const ChangeTheme = () => {
    const { toggleTheme, theme } = useTheme(); // Get the current theme

    return (
        <div>
            <button onClick={toggleTheme}>
                Change to {theme === 'light' ? 'Dark' : 'Light'} Theme
            </button>
        </div>
    );
};

export default ChangeTheme;
