import React, { useState, useEffect, useCallback, useRef } from 'react';
import './../design-UI/style.css';
import { useTheme } from './../themecomponent/ThemeContext';

const LoginFormComp = () => {
    const { theme } = useTheme();
    const [user_name, setUname] = useState('');
    const [pass_word, setPword] = useState('');
    const [first_name] = useState('Neil Raphael');
    const [middle_name] = useState('Magdales');
    const [last_name] = useState('Ramos');
    const [section] = useState('BSIT-3A');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const usernameRef = useRef(null);
    const passwordRef = useRef(null);

    const userCredentials = useRef({
        username: 'user',
        password: 'Password123@'
    });

    const handleLogin = useCallback(() => {
        if (user_name === userCredentials.current.username && pass_word === userCredentials.current.password) {
            setIsLoggedIn(true);
        } else {
            alert('Invalid credentials!');
        }
    }, [user_name, pass_word]);

    const handleLogout = useCallback(() => {
        setIsLoggedIn(false);
        setUname('');
        setPword('');
        if (usernameRef.current) usernameRef.current.focus();
    }, []);

    useEffect(() => {
        if (isLoggedIn) {
            console.log(`User logged in: ${first_name} ${middle_name} ${last_name}, Section: ${section}`);
            alert("You are logged in!");
        } else if (usernameRef.current) {
            usernameRef.current.focus();
        }
    }, [isLoggedIn, first_name, middle_name, last_name, section]);

    const passwordVisibility = () => {
        setShowPassword(prev => !prev);
    };

    return (
        <div className={`container-2 ${theme}`}>
            <div className={`loginform ${theme}`}>
                <h1>Login</h1>
                {!isLoggedIn ? (
                    <>
                        <label className={`usernamelabel ${theme}`}>Username</label>
                        <br />
                        <input
                            ref={usernameRef}
                            placeholder='your username'
                            value={user_name}
                            onChange={(e) => setUname(e.target.value)}
                        />
                        <br />
                        <label className={`passwordlabel ${theme}`}>Password</label>
                        <br />
                        <input
                            ref={passwordRef}
                            type={showPassword ? 'text' : 'password'}
                            placeholder='your password'
                            value={pass_word}
                            onChange={(e) => setPword(e.target.value)}
                        />
                        <br />
                        <label className={`showpasslabel ${theme}`}>
                            <input
                                type="checkbox"
                                checked={showPassword}
                                onChange={passwordVisibility}
                            />
                            Show Password
                        </label>
                        <br />
                        <button className={`btnlogin ${theme}`} onClick={handleLogin}>Login</button>
                    </>
                ) : (
                    <div className='user-info'>
                        <h2>Welcome!</h2>
                        <p>First Name: {first_name}</p>
                        <p>Middle Name: {middle_name}</p>
                        <p>Last Name: {last_name}</p>
                        <p>Section: {section}</p>
                        <button className={`btnlogout ${theme}`} onClick={handleLogout}>Logout</button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default LoginFormComp;