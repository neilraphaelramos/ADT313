import React, { useState } from 'react';
import { useTheme } from './../themecomponent/ThemeContext'; // Adjust the path as necessary

const Calculator = () => {
    const { theme } = useTheme(); // Get the current theme
    const [num1, setNum1] = useState('');
    const [num2, setNum2] = useState('');
    const [answer, setAnswer] = useState('');
    const [operation, setOperation] = useState(''); // State for selected operation

    const handleCalculation = (op) => {
        const number1 = parseFloat(num1);
        const number2 = parseFloat(num2);
        let res = '';

        switch (op) {
            case 'add':
                res = number1 + number2;
                break;
            case 'subtract':
                res = number1 - number2;
                break;
            case 'multiply':
                res = number1 * number2;
                break;
            case 'divide':
                res = number2 !== 0 ? number1 / number2 : 'Cannot divide by zero';
                break;
            default:
                res = 'Select an operation';
        }

        setAnswer(res);
        setOperation(op === 'add' ? '+' : op === 'subtract' ? '-' : op === 'multiply' ? '×' : '÷'); // Set the selected operation
    };

    return (
        <div className={`calculator-container ${theme}`}> {/* Apply theme class */}
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '20px' }}>
                <input
                    type="text"
                    value={num1}
                    onChange={(e) => setNum1(e.target.value)}
                    placeholder="Enter first number"
                    className={`input ${theme}`} // Apply theme class
                    style={{ marginRight: '10px' }}
                />
                <p style={{ margin: '0 10px' }}>{operation}</p>
                <input
                    type="text"
                    value={num2}
                    onChange={(e) => setNum2(e.target.value)}
                    placeholder="Enter second number"
                    className={`input ${theme}`} // Apply theme class
                    style={{ marginRight: '10px' }}
                />
                <p style={{ margin: '0 10px' }}>=</p>
                <input
                    type="text"
                    value={answer}
                    readOnly // Make the answer input read-only
                    placeholder="Answer"
                    className={`input ${theme}`} // Apply theme class
                    style={{ marginLeft: '10px' }}
                />
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                <button onClick={() => handleCalculation('add')}>+</button>
                <button onClick={() => handleCalculation('subtract')}>-</button>
                <button onClick={() => handleCalculation('multiply')}>×</button>
                <button onClick={() => handleCalculation('divide')}>÷</button>
            </div>
        </div>
    );
};

export default Calculator;
