import './App.css';
import { ThemeProvider } from './components/themecomponent/ThemeContext';
import LoginFormComp from './components/loginformcomponent/LoginForm';
import Datastudentinfo from './components/studentinformationcomponent/studentinfo';
import ChangeTheme from './components/themecomponent/ChnageTheme';
import Calculator from './components/calculatorcomponent/Calculator';

function App() {
  return (
    <div className="App">
      <ThemeProvider>
        <Datastudentinfo />
        <LoginFormComp />
        <Calculator />
        <ChangeTheme />
      </ThemeProvider>
    </div>
  );
}

export default App;
